var randomWordArr = ["cat", "dog"];
//here we define the array of the words to choose from
var randomWord = randomWordArr[Math.floor(Math.random() * randomWordArr.length)];
//radomly choose one of these words

var s;
var count = 5;
var answerArray = [];
//empty array for the guesses

var i;

function startUp()
{
    for (var i = 0; i < randomWord.length; i++ )
    //filed the answer with under scores
    //the numver of the underscores is the number of letters in the radom choosed word
    {
        answerArray[i] = "_";
       
    }

    //put them in the atring
    s = answerArray.join(" ");
    document.getElementById("answer").innerHTML = s;
}


function Letter() 
{
    //the later that the person typed in the box
    var letter = document.getElementById("letter").value;
    //
    if (letter.length > 0)
    {
        for (var i = 0; i < randomWord.length; i++)
        {
            //if the randomword have a letter that the person typed 
            if (randomWord[i] === letter) 
            {
                //then assign it 
                answerArray[i] = letter;
            }
            else
            {
                document.getElementById("Lives").innerHTML = count - 1;
            }       
        }
        //how many time it takes to guess

       
        count++;
        if (randomWord[i] !== letter)
        {
            document.getElementById("counter").innerHTML = "No of click: " + count;
        }
        else
        {
            document.getElementById("counter").innerHTML = "No of click" + 0;
        }
        document.getElementById("answer").innerHTML = answerArray.join(" ");
    }
    if(count>4)
    {
        document.getElementById("stat"). innerHTML = "you should guessed by now";

    }
    if(count==0){
        alert("You Lose!");
        location.reload();
    }

   
}
