var clickRate = 0;
var myArray = [1,2,3,4,5];
var yourArray = [6,7,8,9,10];
var isDisplayed = 0;


function myFirstfunction(){
	
	debugger;

	if(isDisplayed == 0){
		document.getElementById("myID").innerHTML = "you clicked me"
		isDisplayed = 1;
	}
	else
	{
		document.getElementById("myID").innerHTML = " "
		isDisplayed = 0;
	}
}

$("#jqueryButton").click(function() {
	clickRate = clickRate + 1;

		if(clickRate <= 10)
		{
			$("#jqueryButton").html(clickRate)
		}
	
});

$("#jqueryP").ready(function(){
	for(var i = 0; i < myArray.length; i++)
	{
		$("#jqueryP").append(myArray[i]);
	}
	

});



$("#jqueryP").ready(function(){
	var total = [];
	for( var i = 0; i < myArray[i]; i++)
	{
		total[i] = myArray[i] + yourArray[i];
	}
	document.write( "The sum of all the elements is: " + total ); 

});
