debugger;
var arrayToSort = [];
var threshold = 1000;
var maximumSize = 100;

//the number of elements to place in the array
var numElements = Math.floor(Math.random() * threshold);


//display the array when the document loads
$(document).ready(function() {

    loop("myList");

});

//execute the bubble sort algorithm
$("#bubbleSort").click(function() {

    //current time on start
    $("#currentTime1").html(new Date());

   
   
    $("#bubbleSortResult").html(loop("bubbleSortResult"));


    bubbleSort("sort");

    //current time once complete
    $("#endTime1").html(new Date());

});

//execute the insertion sort algorithm
$("#insertionSort").click(function() {

    //current time on start
    $("#currentTime2").html(new Date());

    $("#insertionSortResult").html(loop("insertionSortResult"));
    //write insertion sort here

    //current time once complete
    $("#endTime2").html(new Date());

});

//execute the selection sort algorithm
$("#selectionSort").click(function() {

    //current time on start
    $("#currentTime3").html(new Date());

    $("#selectionSortResult").html(loop("selectionSortResult"));
    
    //write selection sort here

    //current time once complete
    $("#endTime3").html(new Date());

});

function loop(myId) {
    $("#" + myId).append("[");

    if(arrayToSort.length == 0)
    {
        //populate the array with random numbers
        for(var i = 0; i < numElements; i = i + 1)
        {
            var num = Math.floor(Math.random() * maximumSize);
            arrayToSort.push(num);

            if(i == numElements - 1)
                $("#" + myId).append(num);
            else
                $("#" + myId).append(num + ", ");
        }
    }
    else
    {
        for(var i = 0; i < numElements; i = i + 1)
        {
            if(i == numElements - 1)
                $("#" + myId).append(arrayToSort[i]);
            else
                $("#" + myId).append(arrayToSort[i] + ", ");
        }
    }
    $("#" + myId).append("]");
    
}

function bubbleSort (a) {
	 var bubbleSortResult = myList => { //TODO write bubble sort here
    	do {
    		var changed = false;//when change is ture do the 
    		//for loop, and when change is false dont do this.
    		for (var i = 0; i < myList.length -1; i ++){ 
    		//myList[i] start with 0
    		//iterate through the array
    		//get an error on the last number

    			if (myList[i] > myList[i + 1] ){//if the number is greater than the next number
    				var temp = myList[i];//if is the case then we make a variable nemed temp and
    				myList[i] = myList[i + 1];
    				myList[i + 1] = temp;//then we swap them
    				changed = true;
    			}
    		}
    	} while(changed)
    	return myList
    };
}
 